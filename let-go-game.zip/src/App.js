
// A React game about letting go, now browser-ready with public assets
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import jsPDF from 'jspdf';

const sereneBackground = '/assets/openart-image_uXJ9V2OT_1751971267987_raw.jpg';
const inputBackground = '/assets/openart-image_GMAU2cag_1751971380639_raw.jpg';
const waveSound = '/assets/beach-sound-with-seagulls-218923.mp3';
const inputSound = '/assets/rumble-tension-horror-370001.mp3';
const releaseSound = '/assets/ocean-beach-waves-332383.mp3';

const quotes = [
  "You are not the storm you walked through.",
  "Letting go doesn't mean giving up, it means moving on.",
  "Healing takes time. And that’s okay.",
  "Today is not the whole story.",
  "Even the ocean returns what it cannot hold.",
  "Some pain deserves a goodbye.",
  "You did the best with what you knew. That counts.",
  "One breath at a time. That’s enough."
];

export default function LetGoGame() {
  const [stage, setStage] = useState('input');
  const [thoughts, setThoughts] = useState(['', '', '']);
  const [selectedIndex, setSelectedIndex] = useState('');
  const [releasedThought, setReleasedThought] = useState('');
  const [quote, setQuote] = useState('');
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('thoughtHistory');
      if (stored) setHistory(JSON.parse(stored));
    }
  }, []);

  const handleInput = (i, value) => {
    const updated = [...thoughts];
    updated[i] = value;
    setThoughts(updated);
    new Audio(inputSound).play();
  };

  const handleRelease = () => {
    const idx = parseInt(selectedIndex);
    if (isNaN(idx) || !thoughts[idx]) return alert("Please select a valid thought.");

    const thought = thoughts[idx];
    const newQuote = quotes[Math.floor(Math.random() * quotes.length)];

    new Audio(releaseSound).play();

    setReleasedThought(thought);
    setQuote(newQuote);
    setStage('release');

    const entry = { released: thought, quote: newQuote, date: new Date().toLocaleDateString() };
    const newHistory = [...history, entry];
    setHistory(newHistory);
    localStorage.setItem('thoughtHistory', JSON.stringify(newHistory));
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text("Let Go Journal", 20, 20);
    history.forEach((h, i) => {
      doc.text(`${h.date}:`, 20, 30 + i * 20);
      doc.text(`Let go: ${h.released}`, 20, 36 + i * 20);
      doc.text(`Quote: ${h.quote}`, 20, 42 + i * 20);
    });
    doc.save("let-go-journal.pdf");
  };

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center bg-cover bg-center p-4 text-[#3c2e20] font-serif transition-all duration-1000 relative overflow-hidden"
      style={{ backgroundImage: `url(${stage === 'input' ? inputBackground : sereneBackground})` }}
    >
      <div className="absolute bottom-5 right-5 w-10 h-10 bg-[#fdf6eb] rounded-lg text-2xl flex items-center justify-center cursor-pointer" onClick={() => setShowHistory(!showHistory)}>📅</div>
      {showHistory && (
        <div className="absolute bottom-20 right-5 bg-white/95 text-sm p-4 rounded-lg max-h-[300px] overflow-y-auto w-[270px] shadow-md z-50">
          {history.length ? history.map((h, i) => (
            <div key={i} className="mb-3">
              <strong>{h.date}</strong><br />
              Let go: {h.released}<br />
              Quote: <i>{h.quote}</i>
              <hr className="my-1" />
            </div>
          )) : 'No thoughts yet.'}
          <button onClick={exportPDF} className="mt-2 bg-[#cde8df] px-3 py-1 rounded">Export Journal</button>
        </div>
      )}

      <AnimatePresence>
        {stage === 'input' ? (
          <motion.div
            key="input"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="bg-white/60 p-6 rounded-xl shadow-xl text-center max-w-md w-full"
          >
            <h2 className="text-2xl mb-4">Let go of...</h2>
            {thoughts.map((t, i) => (
              <input
                key={i}
                type="text"
                placeholder={`Thought ${i + 1}`}
                value={t}
                onChange={(e) => handleInput(i, e.target.value)}
                className="block w-full mb-3 p-2 border-2 border-[#a78d72] bg-[#fdf6eb] rounded-lg"
              />
            ))}
            <select value={selectedIndex} onChange={(e) => setSelectedIndex(e.target.value)} className="mt-2 mb-4 p-2 rounded-lg bg-[#cde8df]">
              <option value="" disabled>Select a thought to release</option>
              {thoughts.map((_, i) => <option key={i} value={i}>Thought {i + 1}</option>)}
            </select>
            <button
              onClick={handleRelease}
              disabled={!selectedIndex || !thoughts[selectedIndex]}
              className="bg-[#cde8df] px-4 py-2 rounded-lg font-bold disabled:opacity-50"
            >Let it go</button>
          </motion.div>
        ) : (
          <motion.div
            key="release"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="bg-white/80 p-6 rounded-xl text-center max-w-md w-full shadow-xl relative"
          >
            <h2 className="text-xl font-semibold mb-4">It’s drifting away…</h2>
            <motion.div
              className="text-lg italic absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 whitespace-nowrap"
              initial={{ y: 0, opacity: 1 }}
              animate={{ y: 200, opacity: 0 }}
              transition={{ duration: 3 }}
            >
              “{releasedThought}”
            </motion.div>
            <motion.div
              className="mt-6 text-green-700 text-lg font-medium italic"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2, duration: 2 }}
            >
              {quote}
            </motion.div>
            <button onClick={() => setStage('input')} className="mt-6 bg-[#cde8df] px-4 py-2 rounded-lg font-bold">Start Again</button>
          </motion.div>
        )}
      </AnimatePresence>

      <audio autoPlay loop src={waveSound} />
    </div>
  );
}
